import React from "react";
import Sales from "../components/Sales";

function SalesPage() {
  return (
    <div>
      <h2>Manage Sales</h2>
      <Sales />
    </div>
  );
}

export default SalesPage;
